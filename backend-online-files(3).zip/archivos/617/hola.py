
if "hola" == "Adios":
    print "Son Iguales"
else:
    print "Son diferentes"